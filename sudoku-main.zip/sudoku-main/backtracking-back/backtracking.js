const express = require('express');
const cors = require('cors');
const { Storage } = require('@google-cloud/storage');
const app = express();
const port = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

console.log('Starting server...');

const storage = new Storage();
const bucketName = process.env.BUCKET_NAME;
if (!bucketName) {
    console.error('ERROR: Bucket name is not specified in the environment variables.');
} else {
    console.log(`Using bucket name: ${bucketName}`);
}

async function fetchPuzzles() {
    console.log(`Fetching puzzles from bucket: ${bucketName}`);
    try {
        const [file] = await storage.bucket(bucketName).file('grids2.json').download();
        console.log('Puzzles fetched successfully.');
        return JSON.parse(file.toString());
    } catch (error) {
        console.error('Failed to fetch puzzles:', error);
        throw error;
    }
}

function isSafe(board, row, col, num) {
    const size = board.length;
    let boxRowSize = Math.sqrt(size);
    let boxColSize = Math.sqrt(size);

    for (let i = 0; i < size; i++) {
        if (board[row][i] === num || board[i][col] === num) {
            return false;
        }
    }

    const boxRowStart = row - (row % boxRowSize);
    const boxColStart = col - (col % boxColSize);

    for (let i = 0; i < boxRowSize; i++) {
        for (let j = 0; j < boxColSize; j++) {
            if (board[i + boxRowStart][j + boxColStart] === num) {
                return false;
            }
        }
    }

    return true;
}

function solveSudokuBacktracking(board) {
    const size = board.length;

    for (let i = 0; i < size; i++) {
        for (let j = 0; j < size; j++) {
            if (board[i][j] === 0) {
                for (let num = 1; num <= size; num++) {
                    if (isSafe(board, i, j, num)) {
                        board[i][j] = num;
                        if (solveSudokuBacktracking(board)) {
                            return true;
                        }
                        board[i][j] = 0;
                    }
                }
                return false;
            }
        }
    }
    return true;
}

app.post('/solveSudoku', async (req, res) => {
    console.log('Received solveSudoku request:', JSON.stringify(req.body));
    const startTime = Date.now(); 
    let puzzles;
    try {
        puzzles = await fetchPuzzles();
    } catch (error) {
        console.error('Error in fetchPuzzles:', error);
        return res.status(500).send({ error: 'Failed to load puzzles from storage.' });
    }

    const { size, difficulty } = req.body;
    const puzzleKey = `${size} ${difficulty}`;
    const puzzlesForDifficulty = puzzles[size][puzzleKey];

    if (!puzzlesForDifficulty || puzzlesForDifficulty.length === 0) {
        console.log(`No puzzles available for size: ${size}, difficulty: ${difficulty}`);
        return res.status(404).send({ error: 'No puzzles available for the selected size and difficulty.' });
    }

    const randomPuzzleIndex = Math.floor(Math.random() * puzzlesForDifficulty.length);
    const puzzle = JSON.parse(JSON.stringify(puzzlesForDifficulty[randomPuzzleIndex]));
    const solved = solveSudokuBacktracking(puzzle);

    const endTime = Date.now();
    const solveDuration = endTime - startTime;

    if (solved) {
        console.log('Puzzle solved successfully.');
        res.json({ puzzle, solveDuration });
    } else {
        console.log('Failed to solve the puzzle.');
        res.status(500).send({ error: 'Failed to solve the puzzle.' });
    }
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

app.listen(port, () => {
    console.log(`Backtracking running at http://localhost:${port}`);
});