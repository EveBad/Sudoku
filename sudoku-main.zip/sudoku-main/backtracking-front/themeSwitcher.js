document.addEventListener('DOMContentLoaded', function() {
    const toggle = document.getElementById('toggleTheme');
    toggle.addEventListener('change', function() {
        if (this.checked) {
            document.body.classList.add('dark-theme');
            document.body.classList.remove('animation-gradient-flow');
        } else {
            document.body.classList.remove('dark-theme');
            document.body.classList.add('animation-gradient-flow');
        }
    });
});