require('dotenv').config();
const express = require('express');
const amqp = require('amqplib');
const cors = require('cors');
const { Storage } = require('@google-cloud/storage');

const app = express();
app.use(express.json());
app.use(cors());

const PORT = process.env.PORT || 3000;
const RABBITMQ_URL = process.env.RABBITMQ_URL || 'amqp://rabbit:5672';

let channel;
const solvedPuzzles = {};
const subgridSolutions = {};

const storage = new Storage();
const bucketName = process.env.BUCKET_NAME;

async function connectRabbitMQ() {
    console.log('Connecting to RabbitMQ...');
    try {
        const connection = await amqp.connect(RABBITMQ_URL);
        channel = await connection.createChannel();
        console.log('Asserting queues...');
        await channel.assertQueue('sudokuJobs', { durable: true });
        await channel.assertQueue('sudokuSolved', { durable: true });
        console.log('Connected to RabbitMQ');
        consumeSolutions();
    } catch (error) {
        console.error(`Cannot connect to RabbitMQ. Error: ${error.message}`);
    }
}

connectRabbitMQ().catch(error => console.error('crash in connectRabbitMQ:', error));

function consumeSolutions() {
    console.log('Starting to consume solutions...');
    channel.consume('sudokuSolved', (msg) => {
        try {
            const { id, solvedSubgrid, error, puzzleSize } = JSON.parse(msg.content.toString()); 

            const jobId = id.substring(0, id.lastIndexOf('-subgrid-'));
            const subgridIndex = parseInt(id.substring(id.lastIndexOf('-') + 1), 10);

            if (!subgridSolutions[jobId]) {
                console.warn(`Received a solution for an unknown job ID: ${jobId}`);
                return channel.ack(msg); 
            }

            if (error) {
                console.error(`Error received in solving job ${id}:`, error);
                if (subgridSolutions[jobId].retryCount[subgridIndex] < 3) {
                    subgridSolutions[jobId].retryCount[subgridIndex]++;
                    console.log(`Retrying subgrid ${subgridIndex} for job ID ${jobId}, attempt ${subgridSolutions[jobId].retryCount[subgridIndex]}`);
                    channel.sendToQueue('sudokuJobs', Buffer.from(JSON.stringify({
                        id: `${jobId}-subgrid-${subgridIndex}`,
                        subgrid: subgridSolutions[jobId].subgrids[subgridIndex],
                        constraints: subgridSolutions[jobId].constraints[subgridIndex],
                        puzzleSize: puzzleSize
                    })), { persistent: true });
                    return channel.nack(msg, false, false);
                }
            }

            const isOneDimensional = solvedSubgrid.flat().length === solvedSubgrid.length;
            const formattedSubgrid = isOneDimensional 
                ? chunkArray(solvedSubgrid, Math.sqrt(solvedSubgrid.length)) 
                : solvedSubgrid;

            if (formattedSubgrid.some(row => row.some(cell => cell == null || cell === undefined))) {
                console.error(`Invalid solved subgrid received for job ${jobId}:`, formattedSubgrid);
                return channel.nack(msg, false, true);
            } else {
                subgridSolutions[jobId].solved++;
                subgridSolutions[jobId].solutions[subgridIndex] = formattedSubgrid;
            }

            if (subgridSolutions[jobId].solved === subgridSolutions[jobId].total) {
                const puzzleSizeForJob = puzzleSize || subgridSolutions[jobId].puzzleSize;
                const assembledSolution = assembleFullGrid(subgridSolutions[jobId].solutions, jobId, puzzleSizeForJob);
                if (assembledSolution) {
                    solvedPuzzles[jobId] = { jobId, solution: assembledSolution };
                    console.log(`Puzzle solved and assembled for job ID: ${jobId}`);
                } else {
                    console.error(`Failed to assemble full grid for job ID: ${jobId}`);
                }
                delete subgridSolutions[jobId];
            }

            channel.ack(msg);
        } catch (e) {
            console.error('Cannot process messages from sudokuSolved queue:', e);
            channel.nack(msg, false, false); 
        }
    }, { noAck: false });
}


function chunkArray(array, size) {
    const chunked = [];
    for (let i = 0; i < array.length; i += size) {
        chunked.push(array.slice(i, i + size));
    }
    return chunked;
}

function validateFullGrid(grid) {
    const size = grid.length;
    const subgridSize = Math.sqrt(size);

    for (let i = 0; i < size; i++) {
        let rowSet = new Set();
        let colSet = new Set();
        for (let j = 0; j < size; j++) {
            if (grid[i][j] !== 0 && rowSet.has(grid[i][j])) return false;
            if (grid[j][i] !== 0 && colSet.has(grid[j][i])) return false;
            rowSet.add(grid[i][j]);
            colSet.add(grid[j][i]);
        }
    }

    for (let blockRow = 0; blockRow < size; blockRow += subgridSize) {
        for (let blockCol = 0; blockCol < size; blockCol += subgridSize) {
            let blockSet = new Set();
            for (let i = 0; i < subgridSize; i++) {
                for (let j = 0; j < subgridSize; j++) {
                    let value = grid[blockRow + i][blockCol + j];
                    if (value !== 0 && blockSet.has(value)) return false;
                    blockSet.add(value);
                }
            }
        }
    }
    return true;
}

function assembleFullGrid(solutions, jobId, puzzleSize) {
    const gridSize = parseInt(puzzleSize.split('x')[0]);
    const subgridSize = Math.sqrt(gridSize);
    let fullGrid = Array.from({ length: gridSize }, () => new Array(gridSize).fill(0));

    solutions.forEach((subgrid, index) => {
        const perRow = gridSize / subgridSize;
        const subgridRowStart = Math.floor(index / perRow) * subgridSize;
        const subgridColStart = (index % perRow) * subgridSize;

        subgrid.forEach((row, rowIndex) => {
            row.forEach((value, colIndex) => {
                fullGrid[subgridRowStart + rowIndex][subgridColStart + colIndex] = value;
            });
        });
    });

    console.log(`Full grid before validation: job ID ${jobId}:`);
    fullGrid.forEach(row => console.log(row.join(' ')));

    if (!validateFullGrid(fullGrid)) {
        console.error(`Validation failed for job ID: ${jobId}`);
        return null; 
    }

    return fullGrid;
}

app.post('/solved', async (req, res) => {
    const { size, difficulty } = req.body;
    const validSizes = ["4x4", "9x9", "16x16", "25x25"];
    const validDifficulties = ["easy", "medium", "hard"];

    if (!validSizes.includes(size) || !validDifficulties.includes(difficulty)) {
        return res.status(400).json({ error: 'Invalid size or difficulty.' });
    }
    
    const fileName = 'grids2.json';

    try {
        const [file] = await storage.bucket(bucketName).file(fileName).download();
        const grids = JSON.parse(file.toString());
        const puzzles = grids[size][`${size} ${difficulty}`];
        const puzzle = puzzles[Math.floor(Math.random() * puzzles.length)];

        const { subgrids, constraints } = breakDownIntoSubgrids(puzzle);
        const jobId = `test-job-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

        subgrids.forEach((subgrid, index) => {
            const subgridId = `${jobId}-subgrid-${index}`;
            const subgridConstraints = constraints[index];
            console.log(`Sending test subgrid ${index} to worker, ID=${subgridId}`);
            channel.sendToQueue('sudokuJobs', Buffer.from(JSON.stringify({
                id: subgridId,
                subgrid,
                constraints: {
                    rowConstraints: subgridConstraints.rowConstraints.map(set => Array.from(set)),
                    colConstraints: subgridConstraints.colConstraints.map(set => Array.from(set))
                },
                globalRowOffset: subgridConstraints.globalRowOffset,
                globalColOffset: subgridConstraints.globalColOffset,
                puzzleSize: size
            })), { persistent: true });
        
            if (!subgridSolutions[jobId]) {
                subgridSolutions[jobId] = { total: subgrids.length, solved: 0, solutions: [], puzzleSize: size };
            }
        });

        res.json({ message: 'Puzzle sent to worker', id: jobId });
    } catch (error) {
        console.error(`Error fetching puzzle from Google Cloud Storage: ${error}`);
        return res.status(500).json({ error: 'Failed to fetch puzzle from storage' });
    }
});

function breakDownIntoSubgrids(puzzle) {
    const gridSize = puzzle.length;
    const subgridSize = Math.sqrt(gridSize);
    let subgrids = [];
    let constraints = [];
    let globalRowConstraints = Array.from({ length: gridSize }, () => new Set());
    let globalColConstraints = Array.from({ length: gridSize }, () => new Set());

    puzzle.forEach((row, rowIndex) => {
        row.forEach((value, colIndex) => {
            if (value !== 0) {
                globalRowConstraints[rowIndex].add(value);
                globalColConstraints[colIndex].add(value);
            }
        });
    });

    for (let rowBlock = 0; rowBlock < gridSize; rowBlock += subgridSize) {
        for (let colBlock = 0; colBlock < gridSize; colBlock += subgridSize) {
            let subgrid = [];
            let subgridConstraints = {
                rowConstraints: new Array(gridSize).fill(null).map(() => new Set()),
                colConstraints: new Array(gridSize).fill(null).map(() => new Set()),
                globalRowOffset: rowBlock,
                globalColOffset: colBlock
            };

            for (let row = rowBlock; row < rowBlock + subgridSize; row++) {
                for (let col = colBlock; col < colBlock + subgridSize; col++) {
                    subgrid.push(puzzle[row][col]);
                    globalRowConstraints[row].forEach(value => subgridConstraints.rowConstraints[row].add(value));
                    globalColConstraints[col].forEach(value => subgridConstraints.colConstraints[col].add(value));
                }
            }

            subgrids.push(subgrid);
            constraints.push(subgridConstraints);
        }
    }

    return { subgrids, constraints };
}

app.get('/solution/:jobId', (req, res) => {
    const { jobId } = req.params;
    if (solvedPuzzles[jobId]) {
        res.json(solvedPuzzles[jobId]);
    } else {
        res.status(404).send('Solution not found');
    }
});

app.listen(PORT, () => {
    console.log(`Controller is running on port ${PORT}.`);
});