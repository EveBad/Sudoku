require('dotenv').config();
const amqp = require('amqplib');

const RABBITMQ_URL = process.env.RABBITMQ_URL || 'amqp://rabbitmq:5672';

async function solveSubgrid(subgrid, constraints, globalRowOffset, globalColOffset) {
    console.log('Starting to solve Sudoku subgrid with constraints:', JSON.stringify(constraints));
    const subgridSize = Math.sqrt(subgrid.length);

    if (!constraints || !constraints.rowConstraints || !constraints.colConstraints) {
        console.error('Invalid constraints provided');
        return null;
    }

    function isValid(num, localRow, localCol) {
        const globalRow = localRow + globalRowOffset;
        const globalCol = localCol + globalColOffset;
        
        console.log(`num ${num} at globalRow ${globalRow}, globalCol ${globalCol}`);
        console.log('Row constraints:', constraints.rowConstraints[globalRow]);
        console.log('Col constraints:', constraints.colConstraints[globalCol]);

        for (let i = 0; i < subgrid.length; i++) {
            const subRow = Math.floor(i / subgridSize);
            const subCol = i % subgridSize;
            if (subgrid[subRow * subgridSize + subCol] === num) {
                return false;
            }
        }
        
        if (constraints.rowConstraints[globalRow]?.includes(num) || constraints.colConstraints[globalCol]?.includes(num)) {
            return false;
        }
        
        return true;
    }

    function solve(index = 0) {
        if (index === subgrid.length) return true;
        const row = Math.floor(index / subgridSize);
        const col = index % subgridSize;
        if (subgrid[index] !== 0) return solve(index + 1);
        for (let num = 1; num <= subgridSize * subgridSize; num++) {
            if (isValid(num, row, col)) {
                subgrid[index] = num;
                if (solve(index + 1)) return true;
                subgrid[index] = 0;
            }
        }
        return false;
    }

    const result = solve();
    if (!result) {
        console.log('Subgrid unsolvable');
        return null;
    }
    console.log('Result for subgrid:', result ? JSON.stringify(subgrid) : 'Unsolvable');
    return result ? subgrid : null;
}

async function startWorker() {
    console.log('Worker connecting to RabbitMQ:', RABBITMQ_URL);
    try {
        const connection = await amqp.connect(RABBITMQ_URL);
        const channel = await connection.createChannel();

        console.log('Connected to RabbitMQ. Starting Queues');
        await channel.assertQueue('sudokuJobs', { durable: true });
        await channel.assertQueue('sudokuSolved', { durable: true });

        console.log('Waiting for sudokuJobs...');
        channel.consume('sudokuJobs', async (msg) => {
            const { id: jobId, subgrid, constraints, globalRowOffset, globalColOffset } = JSON.parse(msg.content.toString());
            console.log(`Subgrid task: ${jobId}, constraints:`, JSON.stringify(constraints));

            try {
                const solvedSubgrid = await solveSubgrid(subgrid, constraints, globalRowOffset, globalColOffset);
                if (solvedSubgrid) {
                    console.log(`Subgrid solved for job ID: ${jobId}. Solution:`, JSON.stringify(solvedSubgrid));
                    channel.sendToQueue('sudokuSolved', Buffer.from(JSON.stringify({ id: jobId, solvedSubgrid })), { persistent: true });
                } else {
                    console.log(`Subgrid unsolvable for job ID: ${jobId}.`);
                    channel.sendToQueue('sudokuSolved', Buffer.from(JSON.stringify({ id: jobId, error: 'Subgrid unsolvable' })), { persistent: true });
                }
            } catch (error) {
                console.error(`Error processing job ID: ${jobId}:`, error);
                channel.sendToQueue('sudokuSolved', Buffer.from(JSON.stringify({ id: jobId, error: error.message })), { persistent: true });
            } finally {
                channel.ack(msg);
            }
        }, { noAck: false });
    } catch (error) {
        console.error('Failed to start worker', error);
    }
}

startWorker().catch(error => console.error('Unexpected error in worker:', error));