const express = require('express');
const cors = require('cors');
const { Storage } = require('@google-cloud/storage');
const app = express();
const port = process.env.PORT || 3003;

app.use(cors());
app.use(express.json());

console.log('Starting server...');
console.log('Environment Variables:', JSON.stringify(process.env, null, 2));

const storage = new Storage();
const bucketName = process.env.BUCKET_NAME;
if (!bucketName) {
    console.error('ERROR: Bucket name is not specified in the environment variables.');
} else {
    console.log(`Using bucket name: ${bucketName}`);
}

async function fetchPuzzles() {
    console.log(`Fetching puzzles from bucket: ${bucketName}`);
    try {
        const [file] = await storage.bucket(bucketName).file('grids2.json').download();
        console.log('Puzzles fetched successfully.');
        return JSON.parse(file.toString());
    } catch (error) {
        console.error('Failed to fetch puzzles:', error);
        throw error;
    }
}

function getPossibleNumbers(grid, row, col, gridSize) {
    const possibleNumbers = new Set(Array.from({ length: gridSize }, (_, i) => i + 1));
    const subGridSize = Math.sqrt(gridSize);
    const subGridRowStart = Math.floor(row / subGridSize) * subGridSize;
    const subGridColStart = Math.floor(col / subGridSize) * subGridSize;

    for (let i = 0; i < gridSize; i++) {
        possibleNumbers.delete(grid[row][i]);
        possibleNumbers.delete(grid[i][col]);
    }

    for (let i = subGridRowStart; i < subGridRowStart + subGridSize; i++) {
        for (let j = subGridColStart; j < subGridColStart + subGridSize; j++) {
            possibleNumbers.delete(grid[i][j]);
        }
    }

    return possibleNumbers;
}

function solveSudokuPuzzle(grid, gridSize) {
    let progress = true;
    while (progress) {
        progress = false;

        for (let row = 0; row < gridSize; row++) {
            for (let col = 0; col < gridSize; col++) {
                if (grid[row][col] === 0) { 
                    const possibleNumbers = getPossibleNumbers(grid, row, col, gridSize);
                    if (possibleNumbers.size === 1) {
                        const [number] = possibleNumbers;
                        grid[row][col] = number;
                        progress = true;
                    }
                }
            }
        }
    }
    return isPuzzleSolved(grid, gridSize);
}

function isPuzzleSolved(grid, gridSize) {
    for (let row = 0; row < gridSize; row++) {
        for (let col = 0; col < gridSize; col++) {
            if (grid[row][col] === 0) {
                return false; 
            }
        }
    }
    return true; 
}

app.post('/solveSudoku', async (req, res) => {
    console.log('Received solveSudoku request:', JSON.stringify(req.body));
    const startTime = Date.now();
    let puzzles;
    try {
        puzzles = await fetchPuzzles();
    } catch (error) {
        console.error('Error fetching puzzles:', error);
        return res.status(500).send({ error: 'Failed to load puzzles from storage.' });
    }

    const { size, difficulty } = req.body;
    const puzzleKey = `${size} ${difficulty}`;
    const puzzlesForDifficulty = puzzles[size][puzzleKey];

    if (!puzzlesForDifficulty || puzzlesForDifficulty.length === 0) {
        console.log(`No puzzles available for size: ${size}, difficulty: ${difficulty}`);
        return res.status(404).send({ error: 'No puzzles available for the selected size and difficulty.' });
    }

    const randomIndex = Math.floor(Math.random() * puzzlesForDifficulty.length);
    const puzzle = JSON.parse(JSON.stringify(puzzlesForDifficulty[randomIndex]));

    const gridSize = puzzle.length;
    const solved = solveSudokuPuzzle(puzzle, gridSize); 

    const endTime = Date.now();
    const solveDuration = endTime - startTime;

    if (solved) {
        console.log('Puzzle solved successfully.');
        res.json({ puzzle, solveDuration });
    } else {
        console.log('Failed to solve the puzzle.');
        res.status(500).send({ error: 'Failed to solve the puzzle.' });
    }
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

app.listen(port, () => {
    console.log(`Sudoku solver running at http://localhost:${port}`);
});